package pl.programista1024.springboot.todowebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
